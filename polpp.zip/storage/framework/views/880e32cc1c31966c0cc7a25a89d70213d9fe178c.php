
  
  

  <?php $__env->startSection('title','data pelanggaran'); ?>

  <?php $__env->startSection('content'); ?>
  

    <div class="pagetitle">
      <h1>Dashboard Pelanggaran</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Dashboard Pelanggaran</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <?php if($message = Session::get('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      Berhasil tambah Data Pelanggaran
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
             <div class="card">
            <div class="card-body">
              <h5 class="card-title">Rekapitulasi</h5>
              <p>Rekapitulasi Data Pelanggaran</p>

              <!-- Table with stripped rows -->
              <table class="table datatable">
                <thead>
                  <tr>
                    
                    
                    <th scope="col">Regu</th>
                    <th scope="col">Kegiatan</th>
                    
                    <th scope="col">Jenis Pelanggaran</th>
                    <th scope="col">Tindak Lanjut</th>
                    <th scope="col">Tanggal</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                    // print_r($pelanggarans[0]);
                  ?>
                  <?php $__currentLoopData = json_decode($pelanggarans); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr>
                      
                      <td><?php echo e($pelanggaran->nama_regu); ?></td>
                      <td><?php echo e($pelanggaran->nama_kegiatan); ?></td>
                      
                      <td><?php echo e($pelanggaran->nama_pelanggaran); ?></td>
                      <td><?php echo e($pelanggaran->nama_tindak_lanjut); ?></td>
                      <td><?php echo e(date_format(date_create($pelanggaran->tgl_peristiwa), "d-M-Y")); ?></td>
                      <td>
                        <button class="btn btn-primary" onclick="underConstruction()">Detail</button> 
                        <button class="btn btn-warning" onclick="underConstruction()">Edit</button> 
                        <button class="btn btn-danger" onclick="underConstruction()">Delete</button>
                      </td>
                    </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
              </table>

              <a class="btn btn-success pull-right" href="<?php echo e(url('pelanggaran/create')); ?>/<?php 
                if(isset($_GET['id_kegiatan'])){ 
                  echo '?id_kegiatan='.$_GET['id_kegiatan'];
                }
              ?>">
              Tambah Data</a>
              <!-- End Table with stripped rows -->

            </div>
          </div>

        </div><!-- End Left side columns -->

        <!-- Right side columns -->
       
      </div>
    </section>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\polpp\resources\views/list_pelanggaran.blade.php ENDPATH**/ ?>