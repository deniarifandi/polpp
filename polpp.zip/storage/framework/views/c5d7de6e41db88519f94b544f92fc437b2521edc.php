


<?php $__env->startSection('title','tambah pelanggaran'); ?>

<?php $__env->startSection('content'); ?>


<div class="pagetitle">
  <h1>Tambah Data Pelanggaran</h1>
  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html">Home</a></li>
      <li class="breadcrumb-item">Pages</li>
      <li class="breadcrumb-item active">Blank</li>
    </ol>
  </nav>
</div><!-- End Page Title -->

    <?php if($message = Session::get('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        Tambah Data Error <?php echo e($message); ?>

      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>

<section class="section">
  <div class="row">

    <div class="col-lg-12">
      <div class="card">

        <div class="card-body">

          <form action="<?php echo e(route('pelanggaran.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>


            <h5 class="card-title" >Detail Laporan</h5>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Jenis Laporan</label>
              <div class="col-sm-8">
                <select class="form-select" aria-label="Default select example" name="id_jenis_laporan" >
                  <option selected value="">- Pilih Jenis Laporan -</option>
                  <option value="1">Laporan Hasil Kegiatan (LHK)</option>
                  <option value="2">Laporan Kegiatan Harian(LKH)</option>
                  <option value="3">Cek Hasil Laporan</option>
                </select>
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Regu</label>
              <div class="col-sm-8">
                <select class="form-select" aria-label="Default select example" name="id_regu" >
                  <option selected value="">- Pilih Regu -</option>
                  <?php $__currentLoopData = $regus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($regu->id); ?>"><?php echo e($regu->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Tanggal</label>
              <div class="col-sm-8">
                <input type="date" name="tgl_peristiwa" class="form-control" >
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Kegiatan</label>
              <div class="col-sm-8">
                <select class="form-select" aria-label="Default select example" name="id_kegiatan" onchange="openForm()">
                  <?php if(isset($_GET['id_kegiatan'])): ?>
                    <option value="<?php echo e($kegiatans[$_GET['id_kegiatan']-1]->id); ?>" selected="selected"><?php echo e($kegiatans[$_GET['id_kegiatan']-1]->nama); ?></option>
                  <?php else: ?>
                    <?php $__currentLoopData = $kegiatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($kegiatan->id); ?>"><?php echo e($kegiatan->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </select>
              </div>
            </div>

          </div>
        </div>
      </div>

      
      <div class="col-lg-6" id="form-reklame" <?php if(isset($_GET['id_kegiatan'])): ?> <?php if($_GET['id_kegiatan'] != 1): ?> style="display: none" <?php endif; ?> <?php endif; ?>>

        <div class="card">
          <div class="card-body">

            <h5 class="card-title" >Detail Pelanggaran</h5>

            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Nama/Tema Reklame</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="tema_reklame">
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Pemilik / Vendor</label>
              <div class="col-sm-8">
                <select class="form-select" aria-label="Default select example" name="id_pemilik" >
                  <option selected value="">- Pilih Pemilik -</option>
                  <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($vendor->id); ?>"><?php echo e($vendor->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Jenis Reklame</label>
              <div class="col-sm-8">
                <select class="form-select" aria-label="Default select example" name="id_jenis_reklame" >
                  <option selected value="">- Pilih Jenis Reklame -</option>
                  <?php $__currentLoopData = $jenis_reklames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis_reklame): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($jenis_reklame->id); ?>"><?php echo e($jenis_reklame->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Ukuran Reklame</label>
              <div class="col-sm-8">
                <select class="form-select" aria-label="Default select example" name="id_ukuran_reklame" >
                  <option selected value="">- Pilih Ukuran Reklame -</option>
                  <?php $__currentLoopData = $ukuran_reklames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ukuran_reklame): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($ukuran_reklame->id); ?>"><?php echo e($ukuran_reklame->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Jumlah Reklame</label>
              <div class="col-sm-8">
                <input type="number" class="form-control" name="jumlah_reklame">
              </div>
            </div>

          </div>
        </div>
      </div>
      

      
      <div class="col-lg-6" id="form-reklame" <?php if(isset($_GET['id_kegiatan'])): ?> <?php if($_GET['id_kegiatan'] != 2): ?> style="display: none" <?php endif; ?> <?php endif; ?>>

        <div class="card">
          <div class="card-body">

            <h5 class="card-title" >Detail Pelanggaran PKL</h5>

            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Jenis PKL</label>
              <div class="col-sm-8">
                 <select class="form-select" aria-label="Default select example" name="id_jenis_pkl" >
                  <option selected value="">- Pilih Jenis PKL -</option>
                  <?php $__currentLoopData = $jenis_pkls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis_pkl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($jenis_pkl->id); ?>"><?php echo e($jenis_pkl->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
           
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Nama Pelaku Usaha</label>
              <div class="col-sm-8">
               <input type="text" class="form-control" name="pkl_nama">
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">No. Identitas</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="pkl_no_identitas">
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Alamat Pelaku Usaha</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="pkl_alamat">
              </div>
            </div>

          </div>
        </div>
      </div>
      

      
      <div class="col-lg-6" id="form-reklame" <?php if(isset($_GET['id_kegiatan'])): ?> <?php if($_GET['id_kegiatan'] != 3): ?> style="display: none" <?php endif; ?> <?php endif; ?>>

        <div class="card">
          <div class="card-body">

            <h5 class="card-title" >Detail Pelanggaran AnJal & GePeng</h5>

            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Jenis AnJal / GePeng</label>
              <div class="col-sm-8">
                 <select class="form-select" aria-label="Default select example" name="id_jenis_anjal_gepeng" >
                  <option selected value="">- Pilih Jenis AnJal / GePeng -</option>
                  <?php $__currentLoopData = $jenis_anjal_gepengs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis_anjal_gepeng): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($jenis_anjal_gepeng->id); ?>"><?php echo e($jenis_anjal_gepeng->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>
           
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Nama AnJal / GePeng</label>
              <div class="col-sm-8">
               <input type="text" class="form-control" name="anjal_gepeng_nama">
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">No. Identitas</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="anjal_gepeng_no_identitas">
              </div>
            </div>

          </div>
        </div>
      </div>
      

      
      <div class="col-lg-6" id="form-reklame" <?php if(isset($_GET['id_kegiatan'])): ?> <?php if($_GET['id_kegiatan'] != 4): ?> style="display: none" <?php endif; ?> <?php endif; ?>>

        <div class="card">
          <div class="card-body">

            <h5 class="card-title" >Detail Pelanggaran PSK</h5>
           
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Nama PSK</label>
              <div class="col-sm-8">
               <input type="text" class="form-control" name="psk_nama">
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">No. Identitas</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="psk_no_identitas">
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Jenis Kelamin</label>
              <div class="col-sm-8">
                 <select class="form-select" aria-label="Default select example" name="psk_kelamin" >
                  <option selected value="">- Pilih Jenis kelamin -</option>
                  <option value="1">Perempuan</option>
                  <option value="2">Laki-laki</option>
                </select>
              </div>
            </div>

          </div>
        </div>
      </div>
      

      
      <div class="col-lg-6" id="form-reklame" <?php if(isset($_GET['id_kegiatan'])): ?> <?php if($_GET['id_kegiatan'] != 5): ?> style="display: none" <?php endif; ?> <?php endif; ?>>

        <div class="card">
          <div class="card-body">

            <h5 class="card-title" >Detail Pelanggaran Minol</h5>
           
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Nama Pemilik Minol</label>
              <div class="col-sm-8">
               <input type="text" class="form-control" name="minol_nama">
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">No. Identitas</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="minol_no_identitas">
              </div>
            </div>

          </div>
        </div>
      </div>
      

        
      <div class="col-lg-6" id="form-reklame" <?php if(isset($_GET['id_kegiatan'])): ?> <?php if($_GET['id_kegiatan'] != 6): ?> style="display: none" <?php endif; ?> <?php endif; ?>>

        <div class="card">
          <div class="card-body">

            <h5 class="card-title" >Detail Pelanggaran Pemondokan</h5>
           
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Nama Pemilik Pemondokan</label>
              <div class="col-sm-8">
               <input type="text" class="form-control" name="pemondokan_nama">
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">No. Identitas</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="pemondokan_no_identitas">
              </div>
            </div>

          </div>
        </div>
      </div>
      

      
      <div class="col-lg-6" id="form-reklame" <?php if(isset($_GET['id_kegiatan'])): ?> <?php if($_GET['id_kegiatan'] != 7): ?> style="display: none" <?php endif; ?> <?php endif; ?>>

        <div class="card">
          <div class="card-body">

            <h5 class="card-title" >Detail Pelanggaran Parkir Liar</h5>
           
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Nama Pelaku Parkir Liar</label>
              <div class="col-sm-8">
               <input type="text" class="form-control" name="parkir_nama">
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">No. Identitas</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="parkir_no_identitas">
              </div>
            </div>

          </div>
        </div>
      </div>
      

       
      <div class="col-lg-6" id="form-reklame" <?php if(isset($_GET['id_kegiatan'])): ?> <?php if($_GET['id_kegiatan'] != 8): ?> style="display: none" <?php endif; ?> <?php endif; ?>>

        <div class="card">
          <div class="card-body">

            <h5 class="card-title" >Detail Prokes</h5>
            
             <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Jenis Penertiban Prokes</label>
              <div class="col-sm-8">
                 <select class="form-select" aria-label="Default select example" name="id_jenis_penertiban_prokes" >
                  <option selected value="">- Pilih Jenis Penertiban Prokes -</option>
                  <?php $__currentLoopData = $jenis_penertiban_prokess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis_penertiban_prokes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($jenis_penertiban_prokes->id); ?>"><?php echo e($jenis_penertiban_prokes->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Jenis Pelaku Usaha</label>
              <div class="col-sm-8">
                 <select class="form-select" aria-label="Default select example" name="id_jenis_pelaku_usaha" >
                  <option selected value="">- Pilih Jenis Pelaku Usaha -</option>
                  <option value="1">Perseorangan</option>
                  <option value="2">Pelaku Usaha</option>
                </select>
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Nama Usaha</label>
              <div class="col-sm-8">
               <input type="text" class="form-control" name="prokes_nama">
              </div>
            </div>
            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">No. Identitas</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" name="prokes_no_identitas">
              </div>
            </div>

          </div>
        </div>
      </div>
      



      
      <div class="col-lg-6" id="form-tindakan">

        <div class="card">
          <div class="card-body">

            <h5 class="card-title" >Lokasi & tindak lanjut</h5>

            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Jenis Pelanggaran</label>
              <div class="col-sm-8">
                <select class="form-select" aria-label="Default select example" id="select_jenis_pelanggaran" name="id_jenis_pelanggaran" >
                  <option selected value="">- Pilih Jenis Pelanggaran -</option>

                  <?php $__currentLoopData = $jenis_pelanggarans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis_pelanggaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($jenis_pelanggaran->id); ?>" class="pelanggaran_kategori_<?php echo e($jenis_pelanggaran->kategori); ?>" style="display: none;"><?php echo e($jenis_pelanggaran->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Tindak Lanjut</label>
              <div class="col-sm-8">
                <select class="form-select" aria-label="Default select example" name="id_tindak_lanjut" >
                  <option selected value="">- Pilih Jenis Tindakan -</option>

                  <?php $__currentLoopData = $tindak_lanjuts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tindak_lanjut): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($tindak_lanjut->id); ?>"><?php echo e($tindak_lanjut->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Kecamatan</label>
              <div class="col-sm-8">
                <select class="form-select" aria-label="Default select example" id="select_kecamatan" name="id_kecamatan" onchange="showKelurahan()" >
                  <option selected value="">- Pilih Kecamatan -</option>


                  <?php $__currentLoopData = $kecamatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kecamatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($kecamatan->id); ?>"><?php echo e($kecamatan->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Kelurahan</label>
              <div class="col-sm-8">
                <select class="form-select" aria-label="Default select example" id="select_kelurahan" name="id_kelurahan" disabled="disabled">
                  <option selected value="">- Pilih Kelurahan -</option>


                  <?php $__currentLoopData = $kelurahans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelurahan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($kelurahan->id); ?>" class="kecamatan_<?php echo e($kelurahan->id_kec); ?> kelurahan_all" style="display: none"><?php echo e($kelurahan->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
              </div>
            </div>

            <div class="row mb-3">
              <label for="inputText" class="col-sm-4 col-form-label">Alamat</label>
              <div class="col-sm-8">
                <input class="form-control" type="text" name="alamat">
              </div>
            </div>

          </div>
        </div>
      </div>

      
      <div class="row">
        <div class="col-lg-4">

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Dokumentasi Foto Sebelum Penertiban</h5>

              <div class="row mb-3">
                
                <div class="col-sm-12">
                  <input class="form-control" type="file" name="foto_sebelum_[1]">
                </div>
              </div>

              <div class="row mb-3">
                
                <div class="col-sm-12">
                  <input class="form-control" type="file" name="foto_sebelum_[2]">
                </div>
              </div>

              <div class="row mb-3">
                
                <div class="col-sm-12">
                  <input class="form-control" type="file" name="foto_sebelum_[3]">
                </div>
              </div>

              <div class="row mb-3">
                
                <div class="col-sm-12">
                  <input class="form-control" type="file" name="foto_sebelum_[4]">
                </div>
              </div>

              <div class="row mb-3">
                
                <div class="col-sm-12">
                  <input class="form-control" type="file" name="foto_sebelum_[5]">
                </div>
              </div>

            </div>
          </div>
        </div>

        <div class="col-lg-4">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Dokumentasi Foto Proses Penertiban</h5>

              <div class="row mb-3">
                
                <div class="col-sm-12">
                  <input class="form-control" type="file" name="foto_proses_[1]">
                </div>
              </div>

              <div class="row mb-3">
                
                <div class="col-sm-12">
                  <input class="form-control" type="file" name="foto_proses_[2]">
                </div>
              </div>

              <div class="row mb-3">
                
                <div class="col-sm-12">
                  <input class="form-control" type="file" name="foto_proses_[3]">
                </div>
              </div>

              <div class="row mb-3">
                
                <div class="col-sm-12">
                  <input class="form-control" type="file" name="foto_proses_[4]">
                </div>
              </div>

              <div class="row mb-3">
                
                <div class="col-sm-12">
                  <input class="form-control" type="file" name="foto_proses_[5]">
                </div>
              </div>
           
          </div>
          </div>
        </div>

        <div class="col-lg-4">
           <div class="card">
            <div class="card-body">
              <h5 class="card-title">Dokumentasi Foto Setelah Penertiban</h5>

              <div class="row mb-3">
                
                <div class="col-sm-12">
                  <input class="form-control" type="file" name="foto_setelah_[1]">
                </div>
              </div>

              <div class="row mb-3">
                
                <div class="col-sm-12">
                  <input class="form-control" type="file" name="foto_setelah_[2]">
                </div>
              </div>

              <div class="row mb-3">
                
                <div class="col-sm-12">
                  <input class="form-control" type="file" name="foto_setelah_[3]">
                </div>
              </div>

              <div class="row mb-3">
                
                <div class="col-sm-12">
                  <input class="form-control" type="file" name="foto_setelah_[4]">
                </div>
              </div>

              <div class="row mb-3">
                
                <div class="col-sm-12">
                  <input class="form-control" type="file" name="foto_setelah_[5]">
                </div>
              </div>

            </div>
            </div>
        </div>  

      </div>
      

      <button type="submit" class="btn btn-success">Simpan</button>

    </form><!-- End General Form Elements -->
    </div>
  </div>
</section>

<script type="text/javascript">
    
    function showReklame(){

      document.getElementById('form-reklame').style.display = "block";
      document.getElementById('form-tindakan').style.display = "block";

    }

    function showKelurahan(){
      document.getElementById('select_kelurahan').value = "";
      var id_kec = document.getElementById("select_kecamatan").value;

      const kelurahan_all = document.getElementsByClassName("kelurahan_all");
      for (let i = 0; i < kelurahan_all.length; i++) {
        kelurahan_all[i].style.display = "none";
      }

      const kelurahan_selected = document.getElementsByClassName("kecamatan_"+id_kec);
      for (let i = 0; i < kelurahan_selected.length; i++) {
        kelurahan_selected[i].style.display = "block";
      }

      if (id_kec == "") {
        document.getElementById('select_kelurahan').disabled = "disabled";
      }else{
        document.getElementById('select_kelurahan').disabled = "";
      }

    }


      (function() {
        var id_kegiatan = <?php echo $_GET['id_kegiatan']; ?>;
        // console.log(kategori_pelanggaran);

        const kegiatan_selected = document.getElementsByClassName("pelanggaran_kategori_"+id_kegiatan);

        for (let i = 0; i < kegiatan_selected.length; i++) {
          kegiatan_selected[i].style.display = "block";
        }

      })();

  
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\polpp\resources\views/insert_pelanggaran.blade.php ENDPATH**/ ?>