
 

 <?php $__env->startSection('title', 'Dashboard'); ?>

 <?php $__env->startSection('content'); ?>

 <div class="pagetitle">
      <h1>Dashboard Pelanggaran</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Dashboard Pelanggaran</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
          <div class="row">

            <!-- REKLAME Card -->
            <div class="col-xxl-4 col-md-4">

              <div class="card info-card sales-card hover-light">

                <a href="<?php echo e(url('pelanggaran')); ?>?id_kegiatan=1">
                   
                  <div class="card-body">
                  <h5 class="card-title">Reklame <span>| Bulan Ini</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center" style="background: #e0f8e9">
                      <img src="assets/img/ad.png" style="max-width: 40px;">
                    </div>
                    <div class="ps-3">
                      <h6><?php echo e($data[0]); ?></h6>
                      
                    </div>
                  </div>
                </div>  

                </a>
                
              </div>
            </div><!-- End Reklame Card -->

            <!-- PKL Card -->
            <div class="col-xxl-4 col-md-4">
              <div class="card info-card revenue-card">

              <a href="<?php echo e(url('pelanggaran')); ?>?id_kegiatan=2">
                <div class="card-body">
                  <h5 class="card-title">PKL <span>| This Month</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                       <img src="assets/img/gerobak.png" style="max-width: 40px;">
                    </div>
                    <div class="ps-3">
                      <h6><?php echo e($data[1]); ?></h6>
                      

                    </div>
                  </div>
                </div>
              </a>

              </div>
            </div><!-- End Reklame Card -->

            <!-- GEPENG Card -->
            <div class="col-xxl-4 col-md-4">
              <div class="card info-card revenue-card">

                  <a href="<?php echo e(url('pelanggaran')); ?>?id_kegiatan=3">

                  <div class="card-body">
                    <h5 class="card-title">AnJal-GePeng <span>| This Month</span></h5>

                    <div class="d-flex align-items-center">
                      <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                        <img src="assets/img/gepeng.png" style="max-width: 50px;">
                      </div>
                      <div class="ps-3">
                         <h6><?php echo e($data[2]); ?></h6>
                        

                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div><!-- End GEPENG Card -->

            <div class="col-xxl-4 col-md-4">
              <div class="card info-card revenue-card">

                  <a href="<?php echo e(url('pelanggaran')); ?>?id_kegiatan=4">

                <div class="card-body">
                  <h5 class="card-title">PSK <span>| This Month</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-gender-ambiguous"></i>
                    </div>
                    <div class="ps-3">
                       <h6><?php echo e($data[3]); ?></h6>
                      

                    </div>
                  </div>
                </div>

                </a>

              </div>
            </div><!-- End PSK Card -->


            <div class="col-xxl-4 col-md-4">
              <div class="card info-card revenue-card">

                <a href="<?php echo e(url('pelanggaran')); ?>?id_kegiatan=5">

                <div class="card-body">
                  <h5 class="card-title"> Minol <span>| This Month</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                       <img src="assets/img/beer.png" style="max-width: 40px;">
                    </div>
                    <div class="ps-3">
                       <h6><?php echo e($data[4]); ?></h6>
                      

                    </div>
                  </div>
                </div>

              </a>

              </div>
            </div><!-- End Revenue Card -->
            <div class="col-xxl-4 col-md-4">
              <div class="card info-card revenue-card">

               <a href="<?php echo e(url('pelanggaran')); ?>?id_kegiatan=6">

                <div class="card-body">
                  <h5 class="card-title">Pemondokan <span>| This Month</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-house-fill"></i>
                    </div>
                    <div class="ps-3">
                       <h6><?php echo e($data[5]); ?></h6>
                      

                    </div>
                  </div>
                </div>

              </a>

              </div>
            </div><!-- End Revenue Card -->
            <div class="col-xxl-4 col-md-4">
              <div class="card info-card revenue-card">

                <a href="<?php echo e(url('pelanggaran')); ?>?id_kegiatan=7">

                <div class="card-body">
                  <h5 class="card-title">Parkir Liar <span>| This Month</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                         <img src="assets/img/park.png" style="max-width: 50px;">
                    </div>
                    <div class="ps-3">
                       <h6><?php echo e($data[6]); ?></h6>
                      

                    </div>
                  </div>
                </div>

                </a>

              </div>
            </div><!-- End Revenue Card -->
            <div class="col-xxl-4 col-md-4">
              <div class="card info-card revenue-card">

               <a href="<?php echo e(url('pelanggaran')); ?>?id_kegiatan=8">

                <div class="card-body">
                  <h5 class="card-title">Prokes <span>| This Month</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <img src="assets/img/mask.png" style="max-width: 60px;">
                    </div>
                    <div class="ps-3">
                       <h6><?php echo e($data[7]); ?></h6>
                      

                    </div>
                  </div>
                </div>

                </a>

              </div>
            </div><!-- End Revenue Card -->
            <div class="col-xxl-4 col-md-4">
              <div class="card info-card revenue-card">

                <a href="#" onclick="underConstruction()">

                <div class="card-body">
                  <h5 class="card-title">Pengaduan <span>| This Month</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <img src="assets/img/pengaduan.png" style="max-width: 50px;">
                    </div>
                    <div class="ps-3">
                       <h6><?php echo e($data[8]); ?></h6>
                      

                    </div>
                  </div>
                </div>

              </a>

              </div>
            </div><!-- End Revenue Card -->

           

          </div>
        </div><!-- End Left side columns -->

        <!-- Right side columns -->
       
      </div>
    </section>
   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\polpp\resources\views/dashboard.blade.php ENDPATH**/ ?>