<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UkuranReklameController extends Controller
{
    //
}
