<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ReguController extends Controller
{
    //
}
