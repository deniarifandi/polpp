<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TindakLanjutController extends Controller
{
    //
}
